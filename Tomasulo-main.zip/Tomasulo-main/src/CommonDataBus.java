
public class CommonDataBus {

}
