import java.util.HashMap;

public class RegisterFile {

	HashMap<String, Double> regFile;

	public RegisterFile() {
		regFile = new HashMap<String, Double>(32);
	}
}
